<div style="background-color: #0a0a0a; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); padding: 40px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Microsoft YaHei', 'Segoe UI', Roboto, sans-serif; margin: 0;">
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #140a00; border: 2px solid #ff8833; border-radius: 12px; margin: 0 auto;">
        <tbody>
        <tr>
            <td style="padding: 0;">
                <!-- 头部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="background-color: #ff6600; background: linear-gradient(90deg, #ff6600 0%, #ff8833 50%, #ff6600 100%); padding: 25px 30px; border-radius: 10px 10px 0 0;">
                            <div style="font-size: 22px; font-weight: bold; color: #0a0a0a; letter-spacing: 2px; text-align: center;">✦ {{$name}} ✦</div>
                        </td>
                    </tr>
                </table>

                <!-- 装饰分割线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 3px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 内容区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 30px 25px;">
                            <!-- 标题 -->
                            <div style="font-size: 20px; color: #ff9933; margin-bottom: 25px; letter-spacing: 1px; text-align: center;">
                                ⚡ 次元验证码 ⚡
                            </div>

                            <!-- 正文 -->
                            <div style="font-size: 15px; color: #cccccc; line-height: 1.8; margin-bottom: 25px;">
                                亲爱的旅行者，你好！<br/><br/>
                                欢迎来到{{$name}}的世界～ 请使用下方的魔法验证码完成身份确认：
                            </div>

                            <!-- 验证码展示框 -->
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="background-color: #1a0d00; border: 2px solid #ff8833; border-radius: 8px; padding: 20px; text-align: center;">
                                        <div style="font-size: 32px; font-weight: bold; color: #ffaa33; letter-spacing: 8px; font-family: 'Courier New', Courier, monospace;">
                                            {{$code}}
                                        </div>
                                    </td>
                                </tr>
                            </table>

                            <!-- 提示信息 -->
                            <div style="font-size: 13px; color: #888888; line-height: 1.6; margin-top: 20px;">
                                ⏰ 验证码将在 5 分钟后失效，请尽快使用哦～<br/>
                                🔒 如果这不是你的操作，请忽略此邮件。
                            </div>
                        </td>
                    </tr>
                </table>

                <!-- 底部装饰线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 2px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 底部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 20px 25px; background-color: #1a0d00;">
                            <a href="{{$url}}" style="font-size: 14px; color: #ff9933; text-decoration: none;">
                                ← 返回 {{$name}}
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->

    <!-- 底部版权信息 -->
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; margin: 0 auto;">
        <tr>
            <td style="padding: 20px; text-align: center;">
                <div style="font-size: 12px; color: #555555;">
                    © {{$name}} · 愿星光指引你的旅途 ✨
                </div>
            </td>
        </tr>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->
</div>


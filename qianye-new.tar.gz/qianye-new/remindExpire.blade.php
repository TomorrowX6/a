<div style="background-color: #0a0a0a; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); padding: 40px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Microsoft YaHei', 'Segoe UI', Roboto, sans-serif; margin: 0;">
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #140a00; border: 2px solid #ff8833; border-radius: 12px; margin: 0 auto;">
        <tbody>
        <tr>
            <td style="padding: 0;">
                <!-- 头部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="background-color: #ff6600; background: linear-gradient(90deg, #ff6600 0%, #ff8833 50%, #ff6600 100%); padding: 25px 30px; border-radius: 10px 10px 0 0;">
                            <div style="font-size: 22px; font-weight: bold; color: #0a0a0a; letter-spacing: 2px; text-align: center;">✦ {{$name}} ✦</div>
                        </td>
                    </tr>
                </table>

                <!-- 装饰分割线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 3px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 内容区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 30px 25px;">
                            <!-- 标题 -->
                            <div style="font-size: 20px; color: #ff9933; margin-bottom: 25px; letter-spacing: 1px; text-align: center;">
                                ⏰ 次元通行证即将过期 ⏰
                            </div>

                            <!-- 正文 -->
                            <div style="font-size: 15px; color: #cccccc; line-height: 1.8; margin-bottom: 20px;">
                                亲爱的旅行者，你好！<br/><br/>
                                温馨提示：你的次元通行证将在 <span style="color: #ff9933; font-weight: bold;">24小时内</span> 到期啦～
                            </div>

                            <!-- 提醒框 -->
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td style="background-color: #1a0d00; border: 2px dashed #ff8833; border-radius: 8px; padding: 20px; text-align: center;">
                                        <div style="font-size: 15px; color: #ffaa44; line-height: 1.8;">
                                            🌟 为了继续你的冒险旅程，请尽快续费哦！<br/>
                                            如果你已经续费，请忽略这条消息～
                                        </div>
                                    </td>
                                </tr>
                            </table>

                            <!-- 续费按钮 -->
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="center" style="padding: 25px 0;">
                                        <a href="{{$url}}" style="display: inline-block; background-color: #ff6600; color: #0a0a0a; font-size: 16px; font-weight: bold; padding: 15px 35px; border-radius: 30px; text-decoration: none; letter-spacing: 1px;">
                                            💫 立即续费 💫
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <!-- 底部装饰线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 2px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 底部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 20px 25px; background-color: #1a0d00;">
                            <a href="{{$url}}" style="font-size: 14px; color: #ff9933; text-decoration: none;">
                                ← 返回 {{$name}}
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->

    <!-- 底部版权信息 -->
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; margin: 0 auto;">
        <tr>
            <td style="padding: 20px; text-align: center;">
                <div style="font-size: 12px; color: #555555;">
                    © {{$name}} · 愿星光指引你的旅途 ✨
                </div>
            </td>
        </tr>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->
</div>


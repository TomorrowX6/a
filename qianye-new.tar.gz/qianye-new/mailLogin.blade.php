<div style="background-color: #0a0a0a; background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%); padding: 40px 20px; font-family: -apple-system, BlinkMacSystemFont, 'Microsoft YaHei', 'Segoe UI', Roboto, sans-serif; margin: 0;">
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #140a00; border: 2px solid #ff8833; border-radius: 12px; margin: 0 auto;">
        <tbody>
        <tr>
            <td style="padding: 0;">
                <!-- 头部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="background-color: #ff6600; background: linear-gradient(90deg, #ff6600 0%, #ff8833 50%, #ff6600 100%); padding: 25px 30px; border-radius: 10px 10px 0 0;">
                            <div style="font-size: 22px; font-weight: bold; color: #0a0a0a; letter-spacing: 2px; text-align: center;">✦ {{$name}} ✦</div>
                        </td>
                    </tr>
                </table>

                <!-- 装饰分割线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 3px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 内容区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 30px 25px;">
                            <!-- 标题 -->
                            <div style="font-size: 20px; color: #ff9933; margin-bottom: 25px; letter-spacing: 1px; text-align: center;">
                                🌙 次元传送门 🌙
                            </div>

                            <!-- 正文 -->
                            <div style="font-size: 15px; color: #cccccc; line-height: 1.8; margin-bottom: 25px;">
                                亲爱的旅行者，你好！<br/><br/>
                                你正在尝试进入{{$name}}的世界，请在 5 分钟内点击下方的传送门链接完成登录：
                            </div>

                            <!-- 登录按钮 -->
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td align="center" style="padding: 20px 0;">
                                        <a href="{{$link}}" style="display: inline-block; background-color: #ff6600; color: #0a0a0a; font-size: 16px; font-weight: bold; padding: 15px 35px; border-radius: 30px; text-decoration: none; letter-spacing: 1px;">
                                            ✨ 点击进入次元 ✨
                                        </a>
                                    </td>
                                </tr>
                            </table>

                            <!-- 链接备用 -->
                            <div style="font-size: 12px; color: #666666; line-height: 1.6; margin-top: 15px; word-break: break-all;">
                                如果按钮无法点击，请复制以下链接：<br/>
                                <span style="color: #ff9933;">{{$link}}</span>
                            </div>

                            <!-- 提示信息 -->
                            <div style="font-size: 13px; color: #888888; line-height: 1.6; margin-top: 20px;">
                                🔒 如果这不是你的操作，请忽略此邮件。
                            </div>
                        </td>
                    </tr>
                </table>

                <!-- 底部装饰线 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="height: 2px; background-color: #ff8833;"></td>
                    </tr>
                </table>

                <!-- 底部区域 -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="padding: 20px 25px; background-color: #1a0d00;">
                            <a href="{{$url}}" style="font-size: 14px; color: #ff9933; text-decoration: none;">
                                ← 返回 {{$name}}
                            </a>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        </tbody>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->

    <!-- 底部版权信息 -->
    <!--[if mso]>
    <table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" border="0">
    <tr><td>
    <![endif]-->
    <table border="0" align="center" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; margin: 0 auto;">
        <tr>
            <td style="padding: 20px; text-align: center;">
                <div style="font-size: 12px; color: #555555;">
                    © {{$name}} · 愿星光指引你的旅途 ✨
                </div>
            </td>
        </tr>
    </table>
    <!--[if mso]>
    </td></tr>
    </table>
    <![endif]-->
</div>

